.. ----------------------------------------------------------------
   SUNDIALS Copyright Start
   Copyright (c) 2002-2021, Lawrence Livermore National Security
   and Southern Methodist University.
   All rights reserved.

   See the top-level LICENSE and NOTICE files for details.

   SPDX-License-Identifier: BSD-3-Clause
   SUNDIALS Copyright End
   ----------------------------------------------------------------

.. include:: ../../../../shared/sunlinsol/SUNLinSol_Band.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_Dense.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_KLU.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_LapackBand.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_LapackDense.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_MagmaDense.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_OneMklDense.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_PCG.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SPBCGS.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SPFGMR.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SPGMR.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SPTFQMR.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SuperLUDIST.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_SuperLUMT.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_cuSolverSp.rst
.. include:: ../../../../shared/sunlinsol/SUNLinSol_Examples.rst
